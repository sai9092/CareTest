package utlitty;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import javax.activation.DataHandler;
import javax.activation.DataSource;
import javax.activation.FileDataSource;


import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.google.common.io.Files;
import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;

import careington_admin_portal_pages.Base_class;



public class Browser_actions extends Base_class {
	public Browser_actions(WebDriver driver) {
		super(driver);
		// TODO Auto-generated constructor stub
	}
	public static WebDriver driver;
	ExtentReports extent;
	 ExtentTest logger;

	/*
	 * public Browser_actions(WebDriver driver){
	 * 
	 * this.driver = driver;
	 * 
	 * //This initElements method will create all WebElements
	 * 
	 * PageFactory.initElements(driver, this);
	 * 
	 * }
	 */
	/*public Browser_actions() {
		// TODO Auto-generated constructor stub
	}*/
	//This a browser action method which is used for send some text
	 public static void type(WebElement locator, String fText) {
			try {			
				locator.clear();
				locator.sendKeys(fText);
				//System.out.println("Entering  "+fText+ "in "+ locator);
				}
			catch (Exception e) {
				System.out.println("Failed Entering"+fText+ "in "+ locator +"<br/>"+"Error is " + e);	
				
			}
		}
		//The below method is used to click an element 
		public static void clickIT(WebElement locator) {
			try {			
				locator.click();
				
				// add logger
			}
			catch (Exception e) {
				System.out.println("Click on element failed");
				System.out.println("Error is " + e);
			}
			
		}
		
		//The below method is used to generate extent report.
		public void startReport(WebDriver driver){
			 //ExtentReports(String filePath,Boolean replaceExisting) 
			 //filepath - path of the file, in .htm or .html format - path where your report needs to generate. 
			 //replaceExisting - Setting to overwrite (TRUE) the existing file or append to it
			 //True (default): the file will be replaced with brand new markup, and all existing data will be lost. Use this option to create a brand new report
			 //False: existing data will remain, new tests will be appended to the existing report. If the the supplied path does not exist, a new file will be created.
			 extent = new ExtentReports (System.getProperty("user.dir") +"/test-output/STMExtentReport.html", true);
			 //extent.addSystemInfo("Environment","Environment Name")
			 extent
			                .addSystemInfo("Host Name", "dailcare	")
			                .addSystemInfo("Environment", "Automation Testing")
			                .addSystemInfo("User Name", "sai perisetty");
			                //loading the external xml file (i.e., extent-config.xml) which was placed under the base directory
			                //You could find the xml file below. Create xml file in your project and copy past the code mentioned below
			                extent.loadConfig(new File(System.getProperty("D:\reports")+"\\extent-config.xml"));
			 }
		// the below method is used for end report of a extent rport 
		
		public void endReport(WebDriver driver){
			 // writing everything to document
			 //flush() - to write or update test information to your report. 
			                extent.flush();
			                //Call close() at the very end of your session to clear all resources. 
			                //If any of your test ended abruptly causing any side-affects (not all logs sent to ExtentReports, information missing), this method will ensure that the test is still appended to the report with a warning message.
			                //You should call close() only once, at the very end (in @AfterSuite for example) as it closes the underlying stream. 
			                //Once this method is called, calling any Extent method will throw an error.
			                //close() - To close all the operation
			                extent.close();
			    }
		
		
		
		
		
		//The below method is used for conditional wait.
		//when system is taking too much time to load use the below method
		public static void explictywait(String locator){
			WebDriverWait wait = new WebDriverWait(driver, 20);			 
			WebElement we = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(locator)));
			
		}
		//The below method is implicty wait extending the browser time period.
		public static void implictwait(){
			driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		}
		
		// the below method is used to select an element in the drop down.
		public static void select_dropdown(WebElement locator,int index){
			try{
				Select sc = new Select(locator);
				sc.selectByIndex(index);
			}
			catch(Exception e){
				System.out.println("this step is failed " );
			}
		}
		
		// The belwo method is used to pick one value fom the drop down 
		
		public static void drop_select(WebElement locator,int value){
			
			
			Select sec = new Select(locator);
			sec.selectByIndex(value);
		}
				
		//the below method is used to scrool down a scroller
		public void scrool_up(WebDriver driver){
			JavascriptExecutor jse = (JavascriptExecutor)driver;
			jse.executeScript("scroll(0, 900);");
			
		}
		//the below method is used to scrool down a scroll bar
		
		public void scrool_down(WebDriver driver){
			JavascriptExecutor jse = (JavascriptExecutor)driver;
			jse.executeScript("scroll(0, 700);");
			
		}
		public void wait_time(){
			try{				
					driver.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
					System.out.println("time to load");
			}
			catch(Exception e){
				System.out.println("try block got failed");
			}
				}
		
		
		//the below methos is testing purpose
		public static  void product_selection(WebElement locator){
			try{
				List<WebElement>Products_page=driver.findElements(By.xpath("//div[@class='product-info']/a/h3"));
				for(WebElement product:Products_page){
					if(product.getText().equals("Diwali Sweet Pack                    ")){
						
						product.click();
						break;
					}else{
						
						System.out.println("loop got failed");
					}
					
				}		
			}
			catch(Exception e){
				
			}
		}
		/*
	//the below method is used to send a executed test report too a specific mail id
	public void email_sending(){
		 
		String to="sai.perisetty@pyramidinc.com";//change accordingly  
		  final String user="sai.perisetty@pyramidinc.com";//change accordingly  
		  final String password="P@ssw0rd";//change accordingly  
		   
		  //1) get the session object     
		  Properties properties = System.getProperties();  
		  properties.setProperty("mail.smtp.host", "webmail.pyramidinc.com");  
		  properties.setProperty("mail.transport.protocol", "smtp");  
		  properties.setProperty("mail.smtp.port", "25");  
		  properties.put("mail.smtp.auth", "true");  
		  System.out.println("sadfdasbdsfafbsda");
		  Session session = Session.getDefaultInstance(properties,  
		   new javax.mail.Authenticator() {  
		   protected PasswordAuthentication getPasswordAuthentication() {  
		   return new PasswordAuthentication(user,password);  
		   }  
		  });  
		  
		  
		     
		  //2) compose message     
		  try{  
		    MimeMessage message = new MimeMessage(session);  
		    message.setFrom(new InternetAddress(user));  
		    message.addRecipient(Message.RecipientType.TO,new InternetAddress(to));  
		    message.setSubject("Messagedasfdsagfdasfdsaf Aleart");  
		      
		    //3) create MimeBodyPart object and set your message text     
		    BodyPart messageBodyPart1 = new MimeBodyPart();  
		    messageBodyPart1.setText("This is message body");  
		      
		    //4) create new MimeBodyPart object and set DataHandler object to this object      
		    MimeBodyPart messageBodyPart2 = new MimeBodyPart();  
		  
		    String filename = "D://EclipseWorkspace//careington2//test-output//emailable-report.html";//change accordingly  
		    DataSource source = new FileDataSource(filename);  
		    messageBodyPart2.setDataHandler(new DataHandler(source));  
		    messageBodyPart2.setFileName(filename);  
		     
		    System.out.println("sdfjkdsa;lfjdsa;");
		     
		    //5) create Multipart object and add MimeBodyPart objects to this object      
		    Multipart multipart = new MimeMultipart();  
		    multipart.addBodyPart(messageBodyPart1);  
		    multipart.addBodyPart(messageBodyPart2);  
		  
		    //6) set the multiplart object to the message object  
		    message.setContent(multipart );  
		     
		    //7) send message  
		    Transport.send(message);  
		   
		   System.out.println("message sent....");  
		   }catch (MessagingException ex) {ex.printStackTrace();}  
		 } */ 
	//the below method is used to take a screen schot fr every page.
	public void screenShot() throws IOException, InterruptedException {
	   File scr = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
	    String filename =  new SimpleDateFormat("yyyyMMddhhmmss'.jpg'").format(new Date());
	    File dest = new File("D:\\screenshots\\screen.jpg" + filename);
	    Files.copy(scr, dest);
	    
	    
		/*
   File scr = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
  
	    File dest = new File("D:\\screenshots\\screen.jpg");
	    Files.copy(scr, dest);
	*/	
	}
	
	
	
	
	
	
	
	
	
}

