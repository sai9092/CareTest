package testcases;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import careington_admin_portal_pages.Member_elegibilitty_page;
import careington_admin_portal_pages.Member_elegibillty_verify_member;
import careington_admin_portal_pages.Member_portal_login_page;

public class Member_ele_admin_portal {
	WebDriver driver;
	@BeforeTest

		
		public void Browser() {
			System.setProperty("webdriver.chrome.driver", "C:\\Users\\fiuser1\\Desktop\\chromedriver.exe");
			driver = new ChromeDriver();
			//driver.manage().window().maximize();
			driver.get("http://10.1.10.83:333/dcmemberui/membereligibility");	
		}
		
	
	@Test
	public void mem() throws InterruptedException{
		
		Member_elegibilitty_page mep = new Member_elegibilitty_page(driver);
		Member_elegibillty_verify_member vme = new Member_elegibillty_verify_member(driver);
		// we should add member portal log in the admi portal pages 
		Member_portal_login_page mpl = new Member_portal_login_page(driver);
		Thread.sleep(5000);
		mep.mem_elegi(null, null, null, null);
		Thread.sleep(5000);
		vme.mem_verify_elg(null, null, null, null, null, null, null, null);
		Thread.sleep(5000);
		mpl.gettest();
		Thread.sleep(5000);
		mpl.gettest2();
		
	}
}
