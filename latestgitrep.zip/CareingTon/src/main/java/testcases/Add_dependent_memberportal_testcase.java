package testcases;

import java.io.IOException;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import careington_admin_portal_pages.Add_dependent_mem_por;
import careington_admin_portal_pages.Login_admin_portal_page;
import careington_admin_portal_pages.Member_portal_login_page;
import utlitty.Browser_actions;

public class Add_dependent_memberportal_testcase {
	static WebDriver driver;
	//The below method is used for testing a member in stage one. 	
	@BeforeTest
	public void Browser() throws InterruptedException {
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\hyd\\Desktop\\chromedriver.exe");
		driver = new ChromeDriver();
		//log.info("==============Browser Started==========");
		//driver.manage().window().maximize();
		Browser_actions ba = new Browser_actions(driver);
		//ba.startReport(driver);
		//Thread.sleep(10000);
		driver.get("https://member.dc-sandbox.com/");	
		driver.manage().window().maximize();
		Thread.sleep(10000);
	}
	
	@Test
	// The below method is used to add a dependent in member portal
	
	public void add_dependent() throws InterruptedException, IOException{
		
		Add_dependent_mem_por admp = new Add_dependent_mem_por(driver);
		Login_admin_portal_page lp = new Login_admin_portal_page(driver);
		lp.login_testcase();
		admp.add_member();
	}
	
	
	
}
