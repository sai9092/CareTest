package testcases;

import java.io.IOException;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import careington_admin_portal_pages.Member_edit_mem_por;
import careington_admin_portal_pages.Member_portal_login_page;

public class Edit_depndent_memberportal {
	static WebDriver driver;
@BeforeTest

public void Browser() {
	System.setProperty("webdriver.chrome.driver", "D:\\driverexefiles\\chromedriver.exe");
	driver = new ChromeDriver();
	//driver.manage().window().maximize();
	driver.get("https://stageone.careington.com/dcmemberui/");	
}
@Test

public void edit_dependent_mempor() throws InterruptedException, IOException
{
	Member_edit_mem_por memp = new Member_edit_mem_por(driver);
	//Member_portal_login mpl = new Member_portal_login();
	Member_portal_login_page mpl = new Member_portal_login_page(driver);
	mpl.member_login_instage();
	memp.edit_member();
}
}
