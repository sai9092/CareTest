package testcases;


import org.apache.logging.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;



import careington_admin_portal_pages.Login_admin_portal_page;
import utlitty.Browser_actions;

public class Login_admin_portal {
	
		WebDriver driver;
		Logger log = org.apache.logging.log4j.LogManager.getLogger(Login_admin_portal.class);
			@BeforeTest
			//The below browser method is used to set the browser 
	public void Browser() throws InterruptedException {
				
				System.setProperty("webdriver.chrome.driver", "C:\\Users\\hyd\\Desktop\\chromedriver.exe");
				driver = new ChromeDriver();
				log.info("==============Browser Started==========");
				//driver.manage().window().maximize();
				Browser_actions ba = new Browser_actions(driver);
				//ba.startReport(driver);
				//Thread.sleep(10000);
				driver.get("https://member.dc-sandbox.com/");	
				driver.manage().window().maximize();
				Thread.sleep(10000);
				
			}
			// the below test case is to login in to admin portal.
			@Test
			public void login () throws InterruptedException {
				Login_admin_portal_page lp = new Login_admin_portal_page(driver);
				lp.login_testcase();
				
				
			}
	/*
	 * @AfterTest public void endreport(){ Browser_actions ba = new
	 * Browser_actions(driver); ba.endReport(driver); }
	 */
			
		
}
