package careington_admin_portal_pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class Member_create_admin_portal_page {
	@FindBy(xpath="//div[@class='row sectionTitle']/div[2]/button") WebElement Add_button;
	@FindBy(xpath="//input[@id='txtFirstName']")WebElement firstname;
	 @FindBy(xpath="//input[@id='middleName']") WebElement middle ;
	  @FindBy(xpath="//input[@id='lastName']") WebElement lastname;
	  @FindBy(xpath="//input[@id='txtAddress1']") WebElement address;
	  @FindBy(xpath="//input[@id='txtCity']") WebElement city;
	  @FindBy(xpath="//input[@id='txtZipCode']") WebElement zip;
	  @FindBy(xpath="//input[@id='txtMobileNumberWithCountryCode']") WebElement phone;
	  @FindBy(xpath="//input[@id='date2']") WebElement dateofbirth;					
	  @FindBy(xpath="//div[@class='container dependentsClass']/div/div/div/div[4]/div/div/div[3]/div[2]/div/p[1]/label/input") WebElement physiciannone;
	  @FindBy(xpath="//select[@id='stateId']") WebElement state;
	  @FindBy(xpath="//select[@id='DependentRelationship']") WebElement relation;
	  @FindBy(xpath="//input[@id='PCPFirstName']") WebElement pcffirstname;
	  @FindBy(xpath="//input[@id='PCPLastName']") WebElement pcffirslastname;
	  @FindBy(xpath="//input[@id='txtMobileNumberWithCountryCode1']") WebElement pcffirsphonenum;
	  @FindBy(xpath="//input[@id='Feet']") WebElement feet;
	  @FindBy(xpath="//input[@id='txtInches']") WebElement inches ;
	  @FindBy(xpath="//input[@id='weightLbsID']") WebElement weight ;
	  @FindBy(xpath="//select[@id='bloodTypeID']") WebElement blood ;
	  @FindBy(xpath="//button[@id='showAddDependentErrors']") WebElement savebutton;
}
