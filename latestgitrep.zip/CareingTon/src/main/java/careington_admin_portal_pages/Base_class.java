package careington_admin_portal_pages;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;

import utlitty.Browser_actions;

public class Base_class {

	
	
	
	public WebDriver driver;
	
	public Base_class(WebDriver driver) {

		this.driver = driver;
		 PageFactory.initElements(driver, this);
		// This initElements method will create all WebElements

		

	}
	
	
	
	
	@BeforeTest
	
	public void Browser() throws InterruptedException {
		
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\hyd\\Desktop\\chromedriver.exe");
		driver = new ChromeDriver();
		//driver.manage().window().maximize();
		Browser_actions ba = new Browser_actions(driver);
		//ba.startReport(driver);
		//Thread.sleep(10000);
		driver.get("https://member.dc-sandbox.com/");	
		driver.manage().window().maximize();
		Thread.sleep(10000);
		
	}
	
	
	
	@AfterTest
	
	
	public void browserend() {
		
		driver.quit();
		
	}
	
	
	
}
