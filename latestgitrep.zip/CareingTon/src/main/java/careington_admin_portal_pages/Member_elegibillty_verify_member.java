package careington_admin_portal_pages;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import utlitty.Browser_actions;

public class Member_elegibillty_verify_member {
	
	WebDriver driver;
	public Member_elegibillty_verify_member(WebDriver driver){

        this.driver = driver;

        //This initElements method will create all WebElements

        PageFactory.initElements(driver, this);

    }
	@FindBy(xpath="//input[@id='createPw']")WebElement current_psw_verifymemberelg;	
	@FindBy(xpath="//input[@id='confirmNewPwID']")WebElement conform_psw_verifymemberelg;
	@FindBy(xpath="//input[@id='PCPFirstName']")WebElement pcpfname_verifymemberelg;
	@FindBy(xpath="//input[@id='PCPLastName']")WebElement pcplname_verifymemberelg;
	@FindBy(xpath="//input[@id='txtMobileNumberWithCountryCode1']")WebElement pcpmob_verifymemberelg;
	@FindBy(xpath="//input[@id='Feet']")WebElement feet_verifymemberelg;
	@FindBy(xpath="//input[@id='Inches']")WebElement inc_verifymemberelg;
	@FindBy(xpath="//input[@id='weightLbsID']")WebElement weight_verifymemberelg;
	//@FindBy(xpath="")WebElement check_verifymemberelg="////input[@class='ng-pristine ng-valid ng-touched']";
	@FindBy(xpath="//button[@id='showErrorsRegPrimary']")WebElement verify_button_elg ;
	@FindBy(xpath="//button[@class='btn btn-primary col-xs-12']")WebElement conformation_button;
	static String cur ;
	public void Scrool_field(WebDriver driver)
	{
		WebElement check_verifymemberelg=driver.findElement(By.xpath("//*[@id='frmRegistrationPrimary']/section/div/div/div/div[1]/div[4]/div/div[2]/div[2]/div/p/input"));
		((JavascriptExecutor) driver).executeScript(
                "arguments[0].scrollIntoView();", check_verifymemberelg);
		
		check_verifymemberelg.click();
	}
    public void mem_verify_elg(String cupsw,String conpsw,String pcpfn,String pcpl,String pcpmn,String vfeet,String vinc,String vweight) throws InterruptedException{
    	Browser_actions ba = new Browser_actions(driver);
    	Member_elegibillty_verify_member vme = new Member_elegibillty_verify_member(driver);
    	driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
    	ba.type( this.current_psw_verifymemberelg, "Test123!");
    	ba.type( this.conform_psw_verifymemberelg, "Test123!");
    	ba.scrool_down(driver);
    	ba.type( this.pcpfname_verifymemberelg, "test");
    	ba.type( this.pcplname_verifymemberelg, "test");
    	ba.type( this.pcpmob_verifymemberelg, "9685749631");
    	Thread.sleep(5000);
    	
    	ba.type( this.feet_verifymemberelg, "5");
    	ba.type( this.inc_verifymemberelg, "5");
    	ba.type( this.weight_verifymemberelg, "123");
    	Thread.sleep(5000);
    	//ba.scrool_down(driver);
    	vme.Scrool_field(driver);
    	
    	Thread.sleep(5000);
    	
    	ba.clickIT( this.verify_button_elg);
    	vme.current_password_get();
    	ba.scrool_down(driver);
    	Thread.sleep(50000);
    	ba.clickIT( this.conformation_button);
    	Thread.sleep(5000);
    	//vme.current_password_get();
    	
    }



    public void current_password_get(){
    	WebElement current = driver.findElement(By.xpath("//input[@id='createPw']"));
    	 cur = current.getAttribute("value");
    	System.out.println(cur);
    }


}
