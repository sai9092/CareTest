package careington_admin_portal_pages;

import static org.testng.Assert.assertEquals;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import utlitty.Browser_actions;

public class Dependent_admin_poratl_edit_page {
	WebDriver driver;
	
	
	
	
	
	
	
	//check this after ten mim i think u inserted wrong code in dependent edit check prpperly with the locators
	
    public Dependent_admin_poratl_edit_page(WebDriver driver){

        this.driver = driver;

        //This initElements method will create all WebElements

        PageFactory.initElements(driver, this);

    }
  //the below locator is mainly used for error message member should be above 18+
  	@FindBy(xpath="//div[@class='errorsContainer']/div/div[2]/div/span[1]")WebElement erormessage ;
  	@FindBy(xpath="//div[@class='row buttons']/div[2]/a[6]")WebElement editlink ;
  	@FindBy(xpath="//input[@id='FirstName']")WebElement editfirstname ;	
  	@FindBy(xpath="//input[@name='LastName']")WebElement editlastname;
  	@FindBy(xpath="//input[@name='Address1']")WebElement editaddress ;
  	@FindBy(xpath="//input[@name='City']")WebElement editcity ;
  	@FindBy(xpath="//input[@name='PhoneNumber']")WebElement editphone ;
  	@FindBy(xpath="//div[@class='wrap']/div/div[2]/form/section/div/div/div/div/div[4]/div/div/div[2]/div[1]/input")WebElement editdob ;
  	@FindBy(xpath="//input[@id='PCPFirstName']")WebElement editpcffirstname ;
  	//this locator is mainly to fail the test case 
  	@FindBy(xpath="//input[@id='PCPFirstNamemmmmmmmmmmmmmmmmmmmm']")WebElement editnegpcffirstname ;
  	@FindBy(xpath="//input[@id='PCPLastName']")WebElement editpcffirslastname ;
  	@FindBy(xpath="//input[@id='txtMobileNumberWithCountryCode1']")WebElement editpcffirsphonenum ;
  	@FindBy(xpath="//input[@name='Feet']")WebElement editfeet ;
  	@FindBy(xpath="//input[@name='Weight']")WebElement editweight ;
  	@FindBy(xpath="//select[@id='bloodTypeID']")WebElement editblood;
  	@FindBy(xpath="//button[@id='showErrorsMemEdit']")WebElement savebuttoneditpage ;
  	
  	@FindBy(xpath="//div[@id='addressNotFoundPopup']/div/div/div[2]/div/div/div[2]/button")WebElement useaddressbutton ;
  	
  	
}
