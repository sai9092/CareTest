package careington_admin_portal_pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import utlitty.Browser_actions;

public class Overage_del_memportal {

	WebDriver driver;
	public Overage_del_memportal(WebDriver driver){
		
		this.driver = driver;
		 PageFactory.initElements(driver, this);
	}
	
		//to delete a overage dep 
	
	
	@FindBy(xpath ="//a[@class='text-center toolTip question']")WebElement odel;
	@FindBy(xpath="(//div[@ng-if='data.OverAge']/following-sibling::div/button[contains(@name,'Delete')])")WebElement delanotheyway;
	@FindBy(xpath="//button[@type='button']")WebElement deletebut;
	
	public void overdel() throws InterruptedException{
		
		Member_portal_login_page mpl = new Member_portal_login_page(driver);
		Browser_actions ba = new Browser_actions(driver);
		mpl.member_login_inlocal();
		Thread.sleep(5000);
		ba.scrool_down(driver);
		
		delanotheyway.click();
		//ba.scrool_down(driver);
		
		//String getodel = odel.getAttribute("value");
		
		
		/*Actions act = new Actions(driver);
		act.moveToElement(odel).build().perform();
		//act.clickAndHold(odel).build().perform();
		
		//act.release();
		act.moveToElement(deletebut).build().perform();
		deletebut.click();
		Thread.sleep(5000);
		
		if(odel.isDisplayed()){
			deletebut.click();
		}
		else{
			System.out.println("it is not working as we excepted");
		}*/
		//System.out.println("this the tesxt" + getodel);
	}
}
