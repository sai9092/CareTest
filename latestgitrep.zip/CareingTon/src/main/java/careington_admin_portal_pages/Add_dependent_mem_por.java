package careington_admin_portal_pages;

import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import utlitty.Browser_actions;
import utlitty.ReadExcel;

public class Add_dependent_mem_por  {
	
	WebDriver driver;

	 JavascriptExecutor js = (JavascriptExecutor) driver;
	  public Add_dependent_mem_por(WebDriver driver) {
	  
	  //this.driver = driver;
	  
	  // This initElements method will create all WebElements
	  
	  PageFactory.initElements(driver, this);
	  
	  }
	 
	@FindBy(xpath = "//button[contains(@data-target,'#multiCollapseExample2')]")
	WebElement Add_dependnet_dropdown;
	
	@FindBy(xpath = "//button[starts-with(@class,'btn dc_add')]")
	WebElement Add_dependent_button;
	@FindBy(xpath = "//input[contains(@name,'firstname')]")
	WebElement firstname;
	@FindBy(xpath = "//input[contains(@formcontrolname,'middlename')]")
	WebElement middle;
	@FindBy(xpath = "//input[contains(@formcontrolname,'lastname')]")
	WebElement lastname;
	
	@FindBy(xpath ="//input[contains(@formcontrolname,'email')]")
	WebElement email;
	
	
	@FindBy(xpath = "//input[contains(@formcontrolname,'address1')]")
	WebElement street_address;
	@FindBy(xpath = "//input[contains(@formcontrolname,'city')]")
	WebElement city;
	
	@FindBy(xpath = "//select[contains(@formcontrolname,'state')]")
	WebElement state;
		
	@FindBy(xpath = "//input[contains(@formcontrolname,'zipcode')]")	
	WebElement zip;
	@FindBy(xpath = "//input[contains(@formcontrolname,'phone')]")
	WebElement phone;
	
	@FindBy(xpath ="//button[contains(@data-target,'#medical')]")
	WebElement medinfodrop;
	@FindBy(xpath = "//select[contains(@formcontrolname,'relationship')]")
	WebElement relation;
	@FindBy(xpath = "/html/body/app-root/div/app-add/form/div[1]/div/div/div[1]/div/div[2]/div/div/div/div[1]/div/div[1]/input")
	WebElement dateofbirth;
	@FindBy(xpath = "//div[@class='container dependentsClass']/div/div/div/div[4]/div/div/div[3]/div[2]/div/p[1]/label/input")
	WebElement physiciannone;
	
	@FindBy(xpath = "//input[@id='chkProvider']")
	WebElement pcp_checkboc;
	@FindBy(xpath = "//input[@id='PCPFirstName']")
	WebElement pcffirstname;
	@FindBy(xpath = "//input[@id='PCPLastName']")
	WebElement pcffirslastname;
	@FindBy(xpath = "//input[@id='txtMobileNumberWithCountryCode1']")
	WebElement pcffirsphonenum;
	@FindBy(xpath = "//input[@id='Feet']")
	WebElement feet;
	@FindBy(xpath = "//input[@id='txtInches']")
	WebElement inches;
	@FindBy(xpath = "//input[@id='weightLbsID']")
	WebElement weight;
	@FindBy(xpath = "//select[@id='bloodTypeID']")
	WebElement blood;
	@FindBy(xpath = "//button[contains(@id,'showErrorsChangePwd')]")
	WebElement savebutton;
 
	@FindBy(xpath="//a[contains(text(),'Privacy Polic')]")
	WebElement privacyandpolicy_link;
	
	public void add_member() throws InterruptedException {
		Browser_actions ba = new Browser_actions(driver);
		
		Thread.sleep(2000);
		ba.clickIT(Add_dependnet_dropdown);
		Thread.sleep(5000);
		//ba.scrool_up(driver);
		ba.clickIT(Add_dependent_button);
		Thread.sleep(5000);
		ba.type(this.firstname, "Test");
		Thread.sleep(1000);
		ba.type(this.middle, "m");
		Thread.sleep(2000);
		ba.type(this.lastname, "test");
		
		ba.type(email, "testing@gmail.com");
		
		ba.type(this.street_address, "test");

		Thread.sleep(2000);
		ba.type(this.city, "text");
		ba.select_dropdown(this.state, 2);
		ba.type(this.zip, "12345");
		
		ba.type(this.phone, "1234567890");
		Thread.sleep(5000);
		
		ba.clickIT(medinfodrop);
		
		Thread.sleep(5000);
		ba.select_dropdown(this.relation, 2);
		Thread.sleep(5000);
		ba.type(this.dateofbirth, "11/11/2016");
		Thread.sleep(5000);
		//ba.scrool_down(driver);
		// ba.clickIT(driver, this.physiciannone);
		/*
		 * ba.type(this.pcffirstname, "test"); ba.type(this.pcffirslastname, "test");
		 * ba.type(this.pcffirsphonenum, "1111111119"); ba.type(this.feet, "5");
		 * ba.type(this.inches, "5"); ba.type(this.weight, "555");
		 * ba.select_dropdown(this.blood, 2);
		 */
		ba.clickIT(this.savebutton);
	}

	public void empty_req() throws InterruptedException {
		Browser_actions ba = new Browser_actions(driver);
		ba.scrool_up(driver);
		ba.clickIT(this.Add_dependent_button);
		Thread.sleep(5000);
		ba.type(this.firstname, "Test");
		Thread.sleep(1000);
		ba.type(this.middle, "m");
		Thread.sleep(2000);
		ba.type(this.lastname, "test");

	}

	public void Scrool_field2(WebDriver driver) {
		WebElement savebutton_neg_req = driver
				.findElement(By.xpath("//div[@class='wrap']/div/div[2]/form/section/div/div/div/div[2]/button[1]"));
		((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView();", savebutton_neg_req);

		savebutton_neg_req.click();
	}

	public void add_dep_excell() throws IOException, InterruptedException {

		Browser_actions ba = new Browser_actions(driver);
		ReadExcel re = new ReadExcel();
		Thread.sleep(5000);
		ba.scrool_down(driver);
		ba.clickIT(Add_dependent_button);
		Thread.sleep(5000);
		ba.type(firstname, re.readExcel(1, 1, "Add_depenent"));
		ba.type(lastname, re.readExcel(2, 1, "Add_depenent"));
		ba.type(street_address, re.readExcel(3, 1, "Add_depenent"));
		ba.drop_select(state, 1);
		ba.type(city, re.readExcel(4, 1, "Add_depenent"));
		ba.type(zip, re.readExcel(5, 1, "Add_depenent"));
		ba.drop_select(relation, 1);
		ba.type(dateofbirth, re.readExcel(6, 1, "Add_depenent"));
		ba.clickIT(pcp_checkboc);
		Thread.sleep(5000);

		ba.scrool_down(driver);
		ba.clickIT(savebutton);
	}

}
