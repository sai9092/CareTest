package careington_admin_portal_pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import utlitty.Browser_actions;

public class Search_admin_portal_page {
	
	WebDriver driver;
	public Search_admin_portal_page(WebDriver driver){

        this.driver = driver;

        //This initElements method will create all WebElements

        PageFactory.initElements(driver, this);

    }
	@FindBy(xpath="//div[@class='wrap']/div/div[2]/section/div/div[1]/div/div/form/div[2]/div[2]/input")WebElement emailid;
	@FindBy(xpath="//div[@class='row text-right']/div/button[1]")WebElement searchbutton ;
	@FindBy(xpath="MemberId")WebElement memberid ;	
	@FindBy(xpath="//div[@class='wrap']/div/div[2]/section/div/div[3]/div/table/tbody/tr/td[1]")WebElement member_in_table;
	@FindBy(xpath="//div[@class='modal-content']/div[3]/button[1]")WebElement verifybutton;
	@FindBy(xpath="//div[@class='modal-content']/div[2]/input")WebElement verifycaller ;
	
	
	Browser_actions ba = new Browser_actions(driver);
	public void verifying_member(String email3) throws InterruptedException{
		ba.type( this.emailid, "MadhuTTt@gmail.com");
		
		ba.scrool_up(driver);
		ba.clickIT( this.searchbutton);
		Thread.sleep(5000);
		ba.scrool_up(driver);
		ba.clickIT( this.member_in_table);
	}
	
	
	
	
	
	
	
}
