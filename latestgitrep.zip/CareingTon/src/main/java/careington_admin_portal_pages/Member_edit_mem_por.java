package careington_admin_portal_pages;

import static org.testng.Assert.assertEquals;

import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import utlitty.Browser_actions;
import utlitty.ReadExcel;

public class Member_edit_mem_por {
	WebDriver driver;

	public Member_edit_mem_por(WebDriver driver) {
		this.driver = driver;
		
	}
	@FindBy(xpath="//div[@class='col-sm-5 col-lg-3 text-right']/a[2]") WebElement edit ;
	@FindBy(xpath="//div[@class='col-sm-12']/div/div[2]/div/p[1]/input[2]")WebElement  fname ;
	@FindBy(xpath="//div[@class='col-sm-12']/div/div[2]/div/p[1]/input[4]")WebElement lastname_edit ;
	@FindBy(xpath="//input[@id='txtAddress1']")WebElement address1 ;
	@FindBy(xpath="//input[@id='txtAddress2']")WebElement address_2;
	@FindBy(xpath="//input[@id='City']")WebElement city_edit;
	@FindBy(xpath="//input[@id=\'txtRegistrationPrimaryDOB']")WebElement dob_edit;
	
//the below method is used to edit a member

public void edit_member() throws InterruptedException{	
	Browser_actions ba = new Browser_actions(driver);
	Add_dependent_mem_por mp = new Add_dependent_mem_por(driver);
	
	Thread.sleep(5000);
	ba.clickIT( this.edit);
	Thread.sleep(5000);
	ba.type(this.fname, "test");
	//ba.scrool_down(driver);
	ba.type( this.dob_edit, "11/11/2016");
	mp.Scrool_field2(driver);
	
	assertEquals(driver.findElement(By.xpath("//div[@class='errorsContainer']/div/div[2]/div/span[1]")).getText(), "* First Name cannot exceed 32 characters"
            , "expected message is displayed");
}

//the below method fetching data from excell sheet.

public void edit_member_excell() throws IOException{
	
	Browser_actions ba = new Browser_actions(driver);
	Member_edit_mem_por memep = new Member_edit_mem_por(driver);
	ReadExcel re = new  ReadExcel();
	
	ba.clickIT(edit);
	ba.type(address1, re.readExcel(1, 1,"Edit_member"));
	ba.type(address_2, re.readExcel(2, 1,"Edit_member"));
	ba.type(city_edit, re.readExcel(3, 1, "Edit_member"));
	
	
}




}
