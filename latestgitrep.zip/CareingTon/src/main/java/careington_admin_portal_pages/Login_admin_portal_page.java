package careington_admin_portal_pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import utlitty.Browser_actions;

public class Login_admin_portal_page  {
	WebDriver driver;
	
	
	public Login_admin_portal_page(WebDriver driver){
		
		this.driver = driver;
		//check this parameter while u executing
		PageFactory.initElements(driver, this);
		
	}
	
	//public WebElement test = driver.findElement(By.id("test"));
	// the below locator is used for admin email id text box 
	@FindBy(id="txtUserEmail")   WebElement email1;
	//public WebElement email2 = driver.findElement(By.xpath("//div[@class='well']//form//div[2]//div[2]//input"));
	// the below locator is used for admin email id text box for alternate purpose
	@FindBy (id="txtUserEmail")
	public static WebElement email;
	
	//the below locator is used for password field in admin portal page 
	@FindBy (id="txtPassword")
	public static WebElement password;
	//The below locator is used for click a login button 
	@FindBy(id="showErrorsDiv")
	public static WebElement button ;
	 
	@FindBy(xpath = "//div[@id='primary_login' ]/p[2]")
	public static WebElement cross_check;
	
	
	Browser_actions bow = new Browser_actions(driver);
	
	public void login_testcase() throws InterruptedException{
		Thread.sleep(5000);
		bow.type( this.email1, "arunaasadi67@gmail.com");
		Thread.sleep(5000);
		
		String emailcheck = email1.getAttribute("value");
		
		

			
		System.out.println(emailcheck);
		bow.type(this.password, "Test@123");
		bow.clickIT( this.button);
		Thread.sleep(5000);
		String gettingtext = driver.findElement(By.xpath("//div[@id='primary_login']/p[2]")).getText();
		
		System.out.println(gettingtext);
		
		  if(emailcheck.equalsIgnoreCase(gettingtext)) {
		  System.out.println("data is matching ");
		  
		  } else {
		  
		  
		  System.out.println("dta is not matching "); 
		  }
		 
		
		
	}
	public void login_negtestcase(String email11,String password1) throws InterruptedException{
		Thread.sleep(5000);
		bow.type( this.email, "Admin120520170077@gmail.com");
		bow.type(  this.password, "Test12");
		bow.clickIT( button);
	}
	public void login_negtestcase1(String email11,String password1) throws InterruptedException{
		Thread.sleep(5000);
		
		bow.type( this.email, "Admin120520170077@gmail.com");
		bow.type(  this.password, "Test12");
		bow.clickIT( button);
		String compare = driver.findElement(By.xpath("//div[@id='loginValidations']/div[2]/div/p")).getText();
		String compare2 = " One required";
		Assert.assertEquals(compare,compare2);
	}

}
