package testcases;

import java.io.IOException;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.relevantcodes.extentreports.LogStatus;

import Extentreports.Extentrepvtwo;
import careington_admin_portal_pages.Add_dependent_mem_por;
import careington_admin_portal_pages.Member_elegibilitty_page;
import careington_admin_portal_pages.Member_portal_login_page;
import careington_admin_portal_pages.Member_verify_ete;

public class Endtoend extends Extentrepvtwo{
	static WebDriver driver;
	//The below method is used for testing a member in stage one. 	
	@BeforeTest
	public void Browser() {
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\fiuser1\\Desktop\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("https://stagetwo.careington.com/dcmemberportal");	
	}
	
	@Test
	public void login() throws InterruptedException, IOException{
		Member_portal_login_page mpl = new Member_portal_login_page(driver);
		Member_elegibilitty_page mep = new Member_elegibilitty_page(driver);
		Member_verify_ete ete = new Member_verify_ete(driver);
		Add_dependent_mem_por admp = new Add_dependent_mem_por(driver);
		//Extentrepvtwo et = new Extentrepvtwo();
		Thread.sleep(5000);
		//mpl.member_login_instage();
		test.log(LogStatus.PASS, "test started");
		mep.memeber_ene();
		Thread.sleep(5000);
		
		
		ete.member_verify();
		Thread.sleep(5000);
		String userName = ete.getUsername();
		String password= ete.getPassword();
		ete.selectVerifyButton();

		Thread.sleep(5000);
		mep.complete_reg();
		Thread.sleep(5000);
		/*String userName = ete.getUsername();
		String password= ete.getPassword();*/
		mpl.login_ete(userName, password);
		//mpl.member_login_excell();
		admp.add_dep_excell();
	}
}
