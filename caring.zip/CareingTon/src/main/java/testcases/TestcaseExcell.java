package testcases;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.relevantcodes.extentreports.LogStatus;

import Extentreports.Extentrepvtwo;
import careington_admin_portal_pages.Login_admin_portal_page;
import utlitty.Browser_actions;
import utlitty.ReadExcel;







public class TestcaseExcell extends Extentrepvtwo{
WebDriver driver;
static String baseUrl;

//static WriteEx2 wrt;

	@BeforeTest
	public void browser(){
		
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\fiuser1\\Desktop\\chromedriver.exe");
		driver = new ChromeDriver();
		//driver.manage().window().maximize();
		driver.get("https://stagetwo.careington.com/dcmemberportal");
		
	}
	@Test
	public void testMethod() throws Exception{
		Login_admin_portal_page log = new Login_admin_portal_page(driver);
		/*wrt = new WriteEx2();
		wrt.createSheet("result");*/
		Browser_actions cm = new Browser_actions(driver);
	    ReadExcel re = new ReadExcel();
	   // Extentrepvtwo et = new Extentrepvtwo();
	  // extent = new ExtentTest("","");
	//    test.log(LogStatus.INFO, "test");
	 //    test.log(LogStatus.INFO, "test started");
	    System.out.println("passing the step ");
	    re.readExcel(0, 1,"sheet2");
	    re.readExcel(1, 1,"sheet2");
	    re.readExcel(2, 1,"sheet2");
	    //we.createexc("test2");
	    cm.type(log.email, re.readExcel(1, 1,"sheet2"));
	   
	    
	    System.out.println("test");
	    Browser_actions.type(log.password, re.readExcel(2, 1,"sheet2"));
	    Thread.sleep(5000);
	    cm.clickIT(log.button);
	    System.out.println("button clikced ");
	    //wrt.createexc("test2");
	   // we.createexc("test1");
	   // we.enterDataa(null, null, null, null);
	    
	}
	
	
}
