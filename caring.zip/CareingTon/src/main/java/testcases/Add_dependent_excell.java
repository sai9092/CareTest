package testcases;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import careington_admin_portal_pages.Add_dependent_mem_por;
import utlitty.ReadExcel;

public class Add_dependent_excell {
	static WebDriver driver;
@BeforeTest
public void browser(){
	System.setProperty("webdriver.chrome.driver", "C:\\Users\\fiuser1\\Desktop\\chromedriver.exe");
	driver = new ChromeDriver();
	driver.manage().window().maximize();
}
	@Test
	
	public void adddep(){
		Member_portal_login mpl = new Member_portal_login();
		Add_dependent_mem_por admp = new Add_dependent_mem_por(driver);
		
		ReadExcel re = new ReadExcel();
		
		
		
	}
		
	
	
}

