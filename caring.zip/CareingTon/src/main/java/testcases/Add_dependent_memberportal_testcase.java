package testcases;

import java.io.IOException;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import careington_admin_portal_pages.Add_dependent_mem_por;
import careington_admin_portal_pages.Member_portal_login_page;

public class Add_dependent_memberportal_testcase {
	static WebDriver driver;
	//The below method is used for testing a member in stage one. 	
	@BeforeTest
	public void Browser() {
		System.setProperty("webdriver.chrome.driver", "D:\\driverexefiles\\chromedriver.exe");
		driver = new ChromeDriver();
		//driver.manage().window().maximize();
		driver.get("https://stageone.careington.com/dcmemberui/");	
	}
	
	@Test
	// The below method is used to add a dependent in member portal
	
	public void add_dependent() throws InterruptedException, IOException{
		
		Add_dependent_mem_por admp = new Add_dependent_mem_por(driver);
		Member_portal_login_page mpl = new Member_portal_login_page(driver);
		mpl.member_login_instage();
		admp.add_member();
	}
	
	
	
}
