package testcases;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import careington_admin_portal_pages.Login_admin_portal_page;
import utlitty.Browser_actions;

public class Login_admin_portal {
	
		WebDriver driver;
			@BeforeTest
			//The below browser method is used to set the browser 
			public void Browser() {
				
				System.setProperty("webdriver.chrome.driver", "D:\\driverexefiles\\chromedriver.exe");
				driver = new ChromeDriver();
				//driver.manage().window().maximize();
				Browser_actions ba = new Browser_actions(driver);
				//ba.startReport(driver);
				driver.get("http://10.1.10.83:333/dcadminportal");	
				
			}
			// the below test case is to login in to admin portal.
			@Test
			public void login () throws InterruptedException {
				Login_admin_portal_page lp = new Login_admin_portal_page(driver);
				lp.login_testcase("Admin1205201700@gmail.com", "Test@123");
				
				
			}
			@AfterTest
			public void endreport(){
				Browser_actions ba = new Browser_actions(driver);
				ba.endReport(driver);
			}
			
		
}
