package testcases;

import java.io.IOException;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import careington_admin_portal_pages.Member_edit_mem_por;
import careington_admin_portal_pages.Member_portal_login_page;

public class Member_edit_memberportal {

	WebDriver driver;
	
	@BeforeTest
	public void Browser() {
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\fiuser1\\Desktop\\chromedriver.exe");
		driver = new ChromeDriver();
		//driver.manage().window().maximize();
		driver.get("http://10.1.10.83:333/dcadminportal");	
	}
	
	@Test
	
	public void editmemeber() throws IOException, InterruptedException{
		
		Member_portal_login_page mplp = new Member_portal_login_page(driver);
		Member_edit_mem_por memp = new  Member_edit_mem_por(driver);
		mplp.member_login_excell();
		memp.edit_member_excell();
		
		
		
	}
	
	
	
	
	
}
