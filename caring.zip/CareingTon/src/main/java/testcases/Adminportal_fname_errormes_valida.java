package testcases;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import careington_admin_portal_pages.Login_admin_portal_page;
import careington_admin_portal_pages.Member_edit_admin_portal_page;
import careington_admin_portal_pages.Search_admin_portal_page;
import careington_admin_portal_pages.Verify_callerpopup_AdminPortal;
import utlitty.Browser_actions;

public class Adminportal_fname_errormes_valida {
	static WebDriver driver;
	@BeforeTest
	public void Browser() {
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\fiuser1\\Desktop\\chromedriver.exe");
		driver = new ChromeDriver();
		//driver.manage().window().maximize();
		driver.get("http://10.1.10.83:333/dcmemberui");	
	}
	//The below method is used to compare the first name error message in the member portal for any dependent.
	@Test
	public void neg_member() throws InterruptedException{
		Browser_actions ba = new Browser_actions(driver);
		Login_admin_portal_page log = new Login_admin_portal_page(driver);
		Verify_callerpopup_AdminPortal vcp = new Verify_callerpopup_AdminPortal(driver);
		//Member_page mp = new Member_page(driver);
		Member_edit_admin_portal_page em = new Member_edit_admin_portal_page(driver);
		//ba.wait_time();	
		log.login_testcase("Admin1205201700@gmail.com", "Test123!");
		Search_admin_portal_page sp = new Search_admin_portal_page(driver);
		Thread.sleep(15000);	
		sp.verifying_member("MadhuTTt@gmail.com");
		Thread.sleep(5000);	
		vcp.verifycaller("MadhuTTt@gmail.com");
		em.editnegmember(null);
	}
}
