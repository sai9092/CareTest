package testcases;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import careington_admin_portal_pages.Member_portal_login_page;
import careington_admin_portal_pages.Overage_del_memportal;
import utlitty.Browser_actions;

public class Delete_overage {
	WebDriver driver ;
	@BeforeTest
	
	public void browser(){
		
		System.setProperty("webdriver.chrome.driver", "D:\\driverexefiles\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.get("https://stageone.careington.com/dcmemberui");
			driver.manage().window().maximize();
		}
	
	@Test
	
	public void delete_ove_dep() throws InterruptedException{
		
		Overage_del_memportal odm = new Overage_del_memportal(driver);
		odm.overdel();
		
	}
	
	
	
	
	}
	
	
	
	
	
	
	

