package careington_admin_portal_pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import utlitty.Browser_actions;

public class Test {
	static WebDriver driver;
public static void main(String[] args) throws InterruptedException {
	System.setProperty("webdriver.chrome.driver", "C:\\Users\\fiuser1\\Desktop\\chromedriver.exe");
	driver = new ChromeDriver();
	//driver.manage().window().maximize();
	Browser_actions ba = new Browser_actions(driver);
	ba.startReport(driver);
	driver.get("http://10.1.10.83:333/dcadminportal");	
	//Thread.sleep(5000);
	driver.findElement(By.xpath("//input[@id='txtUserEmail']")).sendKeys("murali");
}
}
