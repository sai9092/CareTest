package careington_admin_portal_pages;

import java.io.IOException;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import utlitty.Browser_actions;
import utlitty.ReadExcel;

public class Member_verify_ete {

	WebDriver driver;
	public Member_verify_ete(WebDriver driver){
		
		this.driver=driver;
		PageFactory.initElements(driver, this);
		
	}
	
	@FindBy(xpath ="//div[@id='addressNotFoundPopup']/div/div/div[2]/div/div/div[2]")WebElement address_popup;
	@FindBy(id="txtUserEmail")
	static WebElement member_email_verify;
	@FindBy(id="createPw")
	static WebElement password;
	@FindBy(id="confirmNewPwID")WebElement confirm_password;
	@FindBy(id="txtFeet")WebElement feet;
	@FindBy(id="txtInches")WebElement inches;
	@FindBy(id="weightLbsID")WebElement weight;
	@FindBy(xpath ="//*[@id='frmRegistrationPrimary']/section/div/div/div/div[1]/div[4]/div/div[3]/div[2]/div/p/input")WebElement checkbox;
	@FindBy(id="showErrorsRegPrimary")WebElement verifybutton;
	
	
	@SuppressWarnings("static-access")
	public void member_verify() throws IOException, InterruptedException{
		Browser_actions ba = new  Browser_actions(driver);
		ReadExcel re = new ReadExcel();
		Member_verify_ete mve = new Member_verify_ete(driver);
		//String emailget =member_email_verify.getAttribute("value");
		Thread.sleep(5000);
		//mve.getUsername();
		System.out.println(member_email_verify);
		ba.type(password, re.readExcel(1, 1,"member_verifying"));
		//mve.getPassword();
		ba.type(confirm_password, re.readExcel(2, 1, "member_verifying"));
		Thread.sleep(5000);
		
		/*String passwordget = password.getAttribute("value");
		System.out.println(passwordget);*/
		ba.scrool_up(driver);
		if(feet.getAttribute("value").isEmpty()){
			
			ba.type(feet, re.readExcel(3, 1, "member_verifying"));
		}
		else{
			
			System.out.println("data is not to provide");
		}
		if(inches.getAttribute("value").isEmpty())
		{
			ba.type(inches, re.readExcel(4, 1, "member_verifying"));
		}
		else{
			System.out.println("data is not to provide");
		}
		
		if(weight.getAttribute("value").isEmpty())
		{
			ba.type(weight, re.readExcel(5, 1, "member_verifying"));
		}
		else{
			System.out.println("data is not to provide");
		}
		
/*		
		ba.clickIT(checkbox);
		
		ba.clickIT(verifybutton);
		Thread.sleep(3000);
		ba.clickIT(address_popup);*/
		
	}
	
	public void selectVerifyButton() throws InterruptedException{
		Browser_actions ba = new  Browser_actions(driver);
		ba.clickIT(checkbox);
		
		ba.clickIT(verifybutton);
		Thread.sleep(3000);
		ba.clickIT(address_popup);
	}
	
	public String getUsername(){
		//String passwordget = password.getAttribute("value");
		return member_email_verify.getAttribute("value");
	}
	public String getPassword(){
		//String emailget =member_email_verify.getAttribute("value");
		return password.getAttribute("value");
	}
	/*String passwordget = password.getAttribute("value");
	
	 String emailget =member_email_verify.getAttribute("value");
	*/
}

