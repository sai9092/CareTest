package careington_admin_portal_pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import utlitty.Browser_actions;

public class Verify_callerpopup_AdminPortal {
	WebDriver driver;
	public Verify_callerpopup_AdminPortal(WebDriver driver){

        this.driver = driver;

        //This initElements method will create all WebElements

        PageFactory.initElements(driver, this);

    }
	@FindBy(xpath="//div[@class='modal-content']/div[2]/input") WebElement verify_email;
	@FindBy(xpath="//div[@class='modal-content']/div[3]/button[1]")WebElement Verify_button;


	public void verifycaller(String verifyemail) throws InterruptedException{
		Browser_actions ba = new Browser_actions(driver);
		Thread.sleep(5000);
		ba.type( this.verify_email,"MadhuTTt@gmail.com");
		Thread.sleep(5000);
		ba.clickIT(this.Verify_button);
	}

}
