package careington_admin_portal_pages;

import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import utlitty.Browser_actions;
import utlitty.ReadExcel;

public class Add_dependent_mem_por {
	WebDriver driver;

	public Add_dependent_mem_por(WebDriver driver){

        this.driver = driver;

        //This initElements method will create all WebElements

        PageFactory.initElements(driver, this);

    }
	
	@FindBy(xpath="//div[@class='row sectionTitle']/div[2]/button")WebElement Add_button ;
	@FindBy(xpath="//input[@id='txtFirstName']")WebElement firstname ;
	 @FindBy(xpath="//input[@id='middleName']")WebElement middle ;
	  @FindBy(xpath="//input[@id='lastName']")WebElement lastname;
	  @FindBy(xpath="//input[@id='txtAddress1']")WebElement address;
	  @FindBy(xpath="//input[@id='txtCity']")WebElement city ;
	  @FindBy(xpath="//input[@id='txtZipCode']")WebElement zip;
	  @FindBy(xpath="//input[@id='txtMobileNumberWithCountryCode']")WebElement phone;
	  @FindBy(xpath="//input[@id='date']")WebElement dateofbirth ;					
	  @FindBy(xpath="//div[@class='container dependentsClass']/div/div/div/div[4]/div/div/div[3]/div[2]/div/p[1]/label/input")WebElement physiciannone ;
	  @FindBy(xpath="//select[@id='stateId']")WebElement state ;
	  @FindBy(xpath="//select[@id='DependentRelationship']")WebElement relation ;
	  @FindBy(xpath="//input[@id='chkProvider']")WebElement pcp_checkboc;
	  @FindBy(xpath="//input[@id='PCPFirstName']")WebElement pcffirstname ;
	  @FindBy(xpath="//input[@id='PCPLastName']")WebElement pcffirslastname;
	  @FindBy(xpath="//input[@id='txtMobileNumberWithCountryCode1']")WebElement pcffirsphonenum;
	  @FindBy(xpath="//input[@id='Feet']")WebElement feet ;
	  @FindBy(xpath="//input[@id='txtInches']")WebElement inches ;
	  @FindBy(xpath="//input[@id='weightLbsID']")WebElement weight;
	  @FindBy(xpath="//select[@id='bloodTypeID']")WebElement blood ;
	  @FindBy(xpath="//button[@id='showErrorsDepAdd']")WebElement savebutton ;
	public void add_member() throws InterruptedException{
		Browser_actions ba = new Browser_actions(driver);
		ba.scrool_up(driver);
		Thread.sleep(2000);
		ba.clickIT( Add_button);
		Thread.sleep(5000);
		ba.type( this.firstname, "Test");
		Thread.sleep(1000);
		ba.type( this.middle, "m"); 
		Thread.sleep(2000);
		ba.type( this.lastname, "test");
		Thread.sleep(2000);
		ba.type( this.address, "test");		
		
		Thread.sleep(2000);
		ba.type( this.city, "text");
		ba.type( this.zip, "12345");
		ba.select_dropdown(this.state, 2);
		 ba.type( this.phone, "1234567890");
		 ba.select_dropdown(this.relation, 1);
		 ba.type( this.dateofbirth, "11/11/2016");
		 Thread.sleep(5000);
		 ba.scrool_down(driver);
		 //ba.clickIT(driver, this.physiciannone);
		 ba.type( this.pcffirstname, "test");
		ba.type( this.pcffirslastname, "test");
		ba.type( this.pcffirsphonenum, "1111111119");
		ba.type( this.feet, "5");
		ba.type( this.inches, "5");
		ba.type( this.weight, "555");
		ba.select_dropdown(this.blood, 2);
		ba.clickIT( this.savebutton);
	}
	
	
	  public void empty_req() throws InterruptedException{
		  Browser_actions ba = new Browser_actions(driver);
		  ba.scrool_up(driver);
			ba.clickIT( this.Add_button);
			Thread.sleep(5000);
			ba.type( this.firstname, "Test");
			Thread.sleep(1000);
			ba.type( this.middle, "m"); 
			Thread.sleep(2000);
			ba.type( this.lastname, "test");
		  
	  }
	  public void Scrool_field2(WebDriver driver)
		{
			WebElement savebutton_neg_req=driver.findElement(By.xpath("//div[@class='wrap']/div/div[2]/form/section/div/div/div/div[2]/button[1]"));
			((JavascriptExecutor) driver).executeScript(
	              "arguments[0].scrollIntoView();", savebutton_neg_req);
			
			savebutton_neg_req.click();
		}

	  
	  
	  
	  public void add_dep_excell() throws IOException, InterruptedException{
		  
		  
		  Browser_actions ba = new Browser_actions(driver);
		  ReadExcel re = new ReadExcel();
		  Thread.sleep(5000);
		  ba.scrool_down(driver);
		  ba.clickIT(Add_button);
		  Thread.sleep(5000);
		  ba.type(firstname, re.readExcel(1, 1, "Add_depenent"));
		  ba.type(lastname, re.readExcel(2, 1, "Add_depenent"));
		  ba.type(address, re.readExcel(3, 1, "Add_depenent"));
		  ba.drop_select(state, 1);
		  ba.type(city, re.readExcel(4, 1, "Add_depenent"));
		  ba.type(zip, re.readExcel(5, 1, "Add_depenent"));
		  ba.drop_select(relation, 1);
		  ba.type(dateofbirth, re.readExcel(6, 1, "Add_depenent"));
		  ba.clickIT(pcp_checkboc);
		  Thread.sleep(5000);
		 
	
		  ba.scrool_down(driver);
		  ba.clickIT(savebutton);
	  }

}
