package careington_admin_portal_pages;

import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import utlitty.Browser_actions;
import utlitty.ReadExcel;

public class Member_portal_login_page {
	 public static WebDriver driver;
	public  Member_portal_login_page(WebDriver driver){

        this.driver = driver;

        //This initElements method will create all WebElements

        PageFactory.initElements(driver, this);

    }
	

	@FindBy(xpath="//div[@class='well']//form//div[3]//div[2]//input")WebElement mem_portal_email ;
	@FindBy (xpath="//input[@id='txtPassword'] ")WebElement mem_portal_password ;
	@FindBy (xpath="//input[@id='showErrorsDiv']")WebElement mem_portal_loginbut ;

	//this method is to log in member portal and verify mail id of member from the member portal dash board.
	public void member_login_inlocal() throws InterruptedException{
		Browser_actions ba = new Browser_actions(driver);
		Thread.sleep(5000);
		ba.type( this.mem_portal_email,"Dtest389@pyramidinc.com");
		Thread.sleep(5000);
		/*String getmembermailid=mem_portal_email.getAttribute("value");
		System.out.println(mem_portal_email);*/
		Thread.sleep(5000);
		ba.type( this.mem_portal_password, "Sai@1234");
		ba.clickIT( this.mem_portal_loginbut);
		
	}
	
	//the below method is used to log in using excell sheet.
	
	public void member_login_excell() throws IOException, InterruptedException{
		
		Browser_actions ba = new Browser_actions(driver);
		Member_portal_login_page mplp = new Member_portal_login_page(driver);
		ReadExcel re = new ReadExcel();
		ba.type(mem_portal_email, re.readExcel(1, 1,"Loginpage"));
		Thread.sleep(5000);
		ba.type(mem_portal_password, re.readExcel(2, 1, "Loginpage"));
		ba.clickIT(mem_portal_loginbut);
		
	}
	
	
	
	
	
	//the below methos is used to log and verify the mail is mating in the member dash board or not.
	public void member_login_instage() throws InterruptedException, IOException{
		Browser_actions ba = new Browser_actions(driver);
		Thread.sleep(5000);
		ba.type( this.mem_portal_email,"firstnameeightyfour@gmail.com");
		//Thread.sleep(5000);
		//this is another way to get the text
		String getmembermailid=mem_portal_email.getAttribute("value");
		System.out.println(getmembermailid);
		Thread.sleep(5000);
		ba.type( mem_portal_password, "Test123!");
		//ba.screenShot();
		ba.clickIT( this.mem_portal_loginbut);
		Thread.sleep(5000);
		WebElement memberdashboardmailidget = driver.findElement(By.xpath("//div[@class='col-sm-4']/p[2]"));
		String getmailiddashbord = memberdashboardmailidget.getText();
		System.out.println(getmailiddashbord);
		
		if(getmembermailid.equalsIgnoreCase(getmailiddashbord)){
			System.out.println("mail id matched");
		}
		else{
			System.out.println("mail id is not matched");
		}
		//ba.screenShot();
		
	}

	public void gettest() throws InterruptedException{
		//Thread.sleep(10000);
		
		 /*WebElement verifyemail=driver.findElement(By.xpath("//input[@id='txtUserEmail']"));
		 String cpta = verifyemail.getAttribute("value");
		 System.out.println("captcha value: "+cpta);*/
		 WebElement mem_portal_email= driver.findElement(By.xpath("//input[@id='txtUserEmail']"));
		 mem_portal_email.sendKeys(Member_elegibilitty_page.emailvalue);
	}
	public void gettest2() throws InterruptedException{
		//Thread.sleep(10000);
		
		 /*WebElement verifyemail=driver.findElement(By.xpath("//input[@id='txtUserEmail']"));
		 String cpta = verifyemail.getAttribute("value");
		 System.out.println("captcha value: "+cpta);*/
		WebElement mem_portal_loginbut =  driver.findElement(By.xpath("//input[@id='showErrorsDiv']"));
		 WebElement mem_portal_password= driver.findElement(By.xpath("//input[@id='txtPassword']"));
		 mem_portal_password.sendKeys(Verify_member_ele.cur);
		 mem_portal_loginbut.click();
	}

	public void login_member_portal(){
		Browser_actions ba = new Browser_actions(driver);
		Member_elegibilitty_page mep = new  Member_elegibilitty_page(driver);
		Verify_member_ele vme = new Verify_member_ele(driver);
		
		
	}
// the below method is used for to test end to end 
public void login_ete(String userNam, String passWord) throws InterruptedException{
	
	Browser_actions ba = new Browser_actions(driver);
	Member_verify_ete mve = new Member_verify_ete(driver);
	Member_portal_login_page mplp = new Member_portal_login_page(driver);
	Thread.sleep(5000);
	ba.type(mve.member_email_verify, userNam);
	Thread.sleep(5000);
	ba.type(mplp.mem_portal_password, passWord);
	ba.clickIT(mem_portal_loginbut);
	
}

}
