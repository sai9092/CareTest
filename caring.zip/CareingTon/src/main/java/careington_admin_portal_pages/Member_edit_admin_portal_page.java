package careington_admin_portal_pages;

import static org.testng.Assert.assertEquals;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import utlitty.Browser_actions;

public class Member_edit_admin_portal_page {
	WebDriver driver;
	public Member_edit_admin_portal_page(WebDriver driver){

        this.driver = driver;

        //This initElements method will create all WebElements

        PageFactory.initElements(driver, this);

    }
	//the below locator is mainly used for error message member should be above 18+
	public static @FindBy(xpath="//div[@class='errorsContainer']/div/div[2]/div/span[1]")WebElement erormessage;
	public static @FindBy(xpath="//div[@class='row buttons']/div[2]/a[6]")WebElement editlink;
	public static @FindBy(xpath="//input[@id='FirstName']")WebElement editfirstname;	
	public static @FindBy(xpath="//input[@name='LastName']")WebElement editlastname;
	public static @FindBy(xpath="//input[@name='Address1']")WebElement editaddress ;
	public static @FindBy(xpath="//input[@name='City']")WebElement editcity;
	public static @FindBy(xpath="//input[@name='PhoneNumber']")WebElement editphone;
	public static @FindBy(xpath="//div[@class='wrap']/div/div[2]/form/section/div/div/div/div/div[4]/div/div/div[2]/div[1]/input")WebElement editdob;
	public static @FindBy(xpath="//input[@id='PCPFirstName']")WebElement editpcffirstname;
		//this locator is mainly to fail the test case 
	public static @FindBy(xpath="//input[@id='PCPFirstNamemmmmmmmmmmmmmmmmmmmm']")WebElement editnegpcffirstname;
	public static @FindBy(xpath="//input[@id='PCPLastName']")WebElement editpcffirslastname;
	public static @FindBy(xpath="//input[@id='txtMobileNumberWithCountryCode1']")WebElement editpcffirsphonenum;
	public static @FindBy(xpath="//input[@name='Feet']")WebElement editfeet;
	public static @FindBy(xpath="//input[@name='Weight']")WebElement editweight;
	public static @FindBy(xpath="//select[@id='bloodTypeID']")WebElement editblood;
	public static @FindBy(xpath="//button[@id='showErrorsMemEdit']")WebElement savebuttoneditpage;
		
	public static @FindBy(xpath="//div[@id='addressNotFoundPopup']/div/div/div[2]/div/div/div[2]/button")WebElement useaddressbutton;

public void editmember(String fname) throws InterruptedException{
	Browser_actions ba = new Browser_actions(driver);
	Thread.sleep(5000);
	// the below two lines are created with the page factor 
	//checking with this key word if code is not working or not
	Browser_actions.clickIT(editlink);
	Thread.sleep(5000);
	ba.type(editfirstname, "test");
	ba.type( this.editfirstname, "Test");
	Thread.sleep(1000);
	ba.type( this.editlastname, "test");
	ba.type( this.editaddress, "test");
	ba.type( this.editcity, "test");
	Thread.sleep(5000);
	ba.type(this.editphone, "11111111111");
	ba.scrool_up(driver);
	Thread.sleep(5000);
	ba.type( this.editdob, "11/11/1987");
	ba.scrool_up(driver);
	ba.type( this.editpcffirstname, "test");
	ba.type( this.editlastname, "test");
	ba.type( this.editpcffirsphonenum, "1111111111");
	Thread.sleep(5000);
	ba.type( this.editfeet, "1");
	ba.type( this.editweight, "100");
	
	Thread.sleep(5000);
	ba.scrool_down(driver);
	ba.select_dropdown(this.editblood, 3);
	Member_edit_admin_portal_page em = new Member_edit_admin_portal_page(driver);
	em.Scrool_field1(driver);
	ba.clickIT( this.savebuttoneditpage);
	Thread.sleep(5000);
	ba.clickIT( this.useaddressbutton);
	
}
public void editmember_for_errormes(String fname) throws InterruptedException{
	Browser_actions ba = new Browser_actions(driver);
	Thread.sleep(5000);
	ba.clickIT( this.editlink);
	Thread.sleep(5000);
	ba.type( this.editfirstname, "Test");
	Thread.sleep(1000);
	ba.type( this.editlastname, "test");
	ba.type( this.editaddress, "test");
	ba.type( this.editcity, "test");
	Thread.sleep(5000);
	ba.type( this.editphone, "11111111111");
	ba.scrool_up(driver);
	Thread.sleep(5000);
	ba.type( this.editdob, "11/11/2016");
	ba.scrool_up(driver);
	ba.type( this.editpcffirstname, "test");
	ba.type( this.editlastname, "test");
	ba.type( this.editpcffirsphonenum, "1111111111");
	Thread.sleep(5000);
	ba.type( this.editfeet, "1");
	ba.type( this.editweight, "100");		
	Thread.sleep(5000);
	ba.scrool_down(driver);
	ba.select_dropdown(this.editblood, 3);
	Member_edit_admin_portal_page em = new Member_edit_admin_portal_page(driver);
	em.Scrool_field1(driver);
	ba.clickIT( this.savebuttoneditpage);
	Thread.sleep(5000);
	ba.clickIT( this.useaddressbutton);
	
}
//To scrool the scrool bar till the error message 
public void Scrool_field_for_error(WebDriver driver)
{
	WebElement errormesage=driver.findElement(By.xpath("//div[@class='errorsContainer']/div/div[2]/div/span[1]"));
	((JavascriptExecutor) driver).executeScript(
            "arguments[0].scrollIntoView();", errormesage);
	
	errormesage.click();
}
public void Scrool_field1(WebDriver driver)
{
	WebElement savebutton_neg=driver.findElement(By.xpath("//button[@id='showErrorsMemEdit']"));
	((JavascriptExecutor) driver).executeScript(
            "arguments[0].scrollIntoView();", savebutton_neg);
	
	savebutton_neg.click();
}

//the below method to get the size of chars in  the first name feild 
/*public void failtc(WebDriver driver){
	WebElement failtcase = driver.findElement(By.xpath("//input[@id='FirstName']"));
	Dimension rows = failtcase.getSize();
	
}*/
public void editnegmember(String fname) throws InterruptedException{
	
	
	Browser_actions ba = new Browser_actions(driver);
	Member_edit_admin_portal_page em1 = new Member_edit_admin_portal_page(driver);
	Thread.sleep(5000);
	ba.clickIT( this.editlink);
	Thread.sleep(5000);
	ba.type( this.editfirstname, "hariramkrishnarajendraveravaraprasadrao");
	int len = driver.findElement(By.xpath("//input[@id='FirstName']")).getAttribute("value").length();
	assertEquals(len, 32);
	/*if (len >32 ){
		System.out.println("exceed 32 char ");
	}*/
	//System.out.println(editfirstname.length());
	Thread.sleep(1000);
	
	ba.type( this.editlastname, "hariramkrishnarajendraveravaraprasadrao");
	Thread.sleep(5000);
	/*ba.type(driver, this.editaddress, "test");
	ba.type(driver, this.editcity, "test");
	Thread.sleep(5000);
	ba.type(driver, this.editphone, "11111111111");
	//ba.scrool_up(driver);
	Thread.sleep(5000);
	ba.type(driver, this.editdob, "11/11/1987");
	ba.type(driver, this.editpcffirstname, "test");
	ba.type(driver, this.editlastname, "test");
	ba.type(driver, this.editpcffirsphonenum, "1111111111");
	Thread.sleep(5000);
	ba.type(driver, this.editfeet, "1");
	ba.type(driver, this.editweight, "100");
	*/
	Thread.sleep(5000);
	ba.scrool_down(driver);
	Thread.sleep(5000);
	ba.scrool_down(driver);
	Thread.sleep(5000);
	ba.scrool_down(driver);
	ba.select_dropdown(this.editblood, 3);
	Thread.sleep(5000);
	//button is not able to click so check the locator 

	em1.Scrool_field1(driver);
	assertEquals(len, 32);
	
	assertEquals(driver.findElement(By.xpath("//input[@id='FirstName']/following-sibling::span[2]")).getText(), "* First Name cannot exceed 32 characters"
                                , "expected message is displayed");
	


}

}