package careington_admin_portal_pages;

import static org.testng.Assert.assertEquals;

import java.io.IOException;
import java.util.Iterator;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;
import org.testng.asserts.Assertion;


import utlitty.Browser_actions;
import utlitty.ReadExcel;

public class Member_elegibilitty_page {
	WebDriver driver;
	public Member_elegibilitty_page(WebDriver driver){

        this.driver = driver;

        //This initElements method will create all WebElements

        PageFactory.initElements(driver, this);

    }
	@FindBy(xpath="//div[@class='well']/div[4]/div/input[1]")WebElement mem_ele_memberid ;
	@FindBy(id="First Name")WebElement mem_ele_firstname ;
	@FindBy(id="Last Name")WebElement mem_ele_lastname ;
	//@FindBy(xpath="//div/form/section/div/div/div/div[@class='well']/div[3]/div/div/input")WebElement mem_ele_dob ;
	@FindBy(xpath="//div[@class='well']/div[5]/button")WebElement mem_ele_verify_button ;
	@FindBy(xpath="//div[@class='wrap']/div/div[2]/section/div/div/div/div[1]/div[2]/table/tbody/tr/td[4]/a")WebElement mem_reg_link ;
	@FindBy(xpath="//div[@class='wrap']/div/div[2]/section/div/div/div/div[2]/div[2]/a/button[2]")WebElement complete_regis_button;

	@FindBy(partialLinkText="Verify your account")WebElement verify_account;
	public static String emailvalue;


	//This method used to get the mail id from the email id field and i used get attribute value if i want to get text then i will use get text method
	public void gettest() throws InterruptedException{
		//Thread.sleep(10000);
		
		 WebElement verifyemail=driver.findElement(By.xpath("//input[@id='txtUserEmail']"));
		 emailvalue = verifyemail.getAttribute("value");
		 System.out.println("captcha value: "+emailvalue);
		 /*WebElement login= driver.findElement(By.xpath("//input[@id='usercaptcha']"));
		 capuser.sendKeys(cpta);*/
	}
//the below method is used for member elgibility 
	public void mem_elegi(String fname,String lname,String zip,String dob) throws InterruptedException{
		Browser_actions ba = new Browser_actions(driver);
		Member_elegibilitty_page mep = new Member_elegibilitty_page(driver);
		ba.type( this.mem_ele_memberid, "3602");
		Thread.sleep(5000);
		ba.type( this.mem_ele_firstname, "TESTpswthree");
		Thread.sleep(5000);
		ba.type( this.mem_ele_lastname, "registration");
		Thread.sleep(10000);
		//ba.type( this.mem_ele_dob, "09/10/1973");
		Thread.sleep(5000);
		ba.scrool_down(driver);
		ba.clickIT( this.mem_ele_verify_button);
		Thread.sleep(5000);
		//ba.clickIT( this.mem_reg_link);
		// we can check the condition in another way also like taking the sect row value ifthe value is displaed then it should clik the sepecific button if not it should clik on member button 
		// the below logic is for to check weather the dependent is avilable  or not under a member with member elegibility.
		//WebElement tabledat = driver.findElement(By.xpath("//div[@class='main']/div[2]/section/div/div/div/div/div/table/tbody/tr/td"));
		//System.out.println();
		Thread.sleep(5000);
		//List<WebElement> list = driver.findElements(By.xpath("//div[@class='main']/div[2]/section/div/div/div/div/div/table/tbody/tr/td"));
		//getting all the list of values from table
		
			//checking in the below condition and try to use hasnext method so that it will check the value.
		
	
		boolean  depnamelocator = driver.findElement(By.xpath("//div[@class='main']/div[2]/section/div/div/div/div/div/table/tbody/tr[2]/td[1]")).isDisplayed();
		WebElement  registerbutton  = driver.findElement(By.xpath("//div[@class='main']/div[2]/section/div/div/div/div/div/table/tbody/tr[2]/td[4]/a"));
		
		
		//System.out.println(depnamelocator.getText());
		if(depnamelocator)
		{
			System.out.println("dependent is visable");
			Thread.sleep(5000);
			registerbutton.click();
			Thread.sleep(5000);
			WebElement errortext = driver.findElement(By.xpath("//div[@class='errorsContainer']/div/div[2]/div/span[3]"));
			//the below four  lines are to compare the error message with assert method 
			String error_message =errortext.getText();
			error_message.trim();
			System.out.println("this is trimeed string:"+error_message);
			Assert.assertEquals( "Primary has to be verified Prior to Dependents",error_message);
			Thread.sleep(5000);
			/*assertEquals(driver.findElement(By.xpath("//div[@class='errorsContainer']/div/div[2]/div/span[3]")).getText(), " Primary has to be verified Prior to Dependents"
                    , "expected message is displayed");	*/
			ba.clickIT( this.mem_reg_link);
		}
		else{
			Thread.sleep(5000);
			ba.clickIT( this.mem_reg_link);
			System.out.println("system is trying to click on member register link ");
		}
		
		/*for(WebElement list1:list){	
		System.out.println(list1.getText());
		}
		
		*/
		Thread.sleep(5000);
		//ba.clickIT(driver, this.verify_button_elg);
	mep.gettest();
		
	}	
	
	
	public void memeber_ene() throws IOException, InterruptedException{
		
		Browser_actions ba = new Browser_actions(driver);
		ReadExcel re = new ReadExcel();
		ba.clickIT(verify_account);
		Thread.sleep(5000);
		ba.type(mem_ele_memberid, re.readExcel(1, 1, "membereligibility" ));
		ba.type(mem_ele_firstname, re.readExcel(2, 1, "membereligibility"));
		ba.type(mem_ele_lastname, re.readExcel(3, 1, "membereligibility"));
		ba.clickIT(mem_ele_verify_button);
		Thread.sleep(5000);
		if(mem_reg_link.isDisplayed()){
			mem_reg_link.click();}
		
			else{
				complete_regis_button.click();
			}
		}
	public void  complete_reg() throws InterruptedException{
		Browser_actions ba = new Browser_actions(driver);
		Thread.sleep(5000);
		ba.clickIT(complete_regis_button);
	}
	
	

}
