package careington_admin_portal_pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import utlitty.Browser_actions;

public class Login_admin_portal_page {
	WebDriver driver;
	
	
	public Login_admin_portal_page(WebDriver driver){
		
		this.driver = driver;
		//check this parameter while u executing
		PageFactory.initElements(driver, this);
		
	}
	
	public WebElement test = driver.findElement(By.id("test"));
	// the below locator is used for admin email id text box 
	@FindBy(xpath="txtUserEmail")   WebElement email1;
	//public WebElement email2 = driver.findElement(By.xpath("//div[@class='well']//form//div[2]//div[2]//input"));
	// the below locator is used for admin email id text box for alternate purpose
	@FindBy (xpath="//input[@id='txtUserEmail']")
	public static WebElement email;
	
	//the below locator is used for password field in admin portal page 
	@FindBy (xpath="//div[@class='well']/form/div[3]/div[2]/input")
	public static WebElement password;
	//The below locator is used for click a login button 
	@FindBy(xpath="//div[@class='well']/form/div[5]/div/input")
	public static WebElement button ;
	//this locator is for demo and it is for negitive testcase case 
	@FindBy(xpath ="//div[@class='well']/form/div[2]/div[2]/input11212") WebElement email11;
	@FindBy(xpath="//html//body//div//div//div[3]//section//div//div//div//div//form//div[7]//div//p[2]//a")WebElement member_elgibility;


	Browser_actions bow = new Browser_actions(driver);


	public void login_testcase(String email,String password1) throws InterruptedException{
		Thread.sleep(5000);
		bow.type( this.email, "Admin1205201700@gmail.com");
		bow.type(this.password, "Test123!");
		bow.clickIT( this.button);
	}
	public void login_negtestcase(String email11,String password1) throws InterruptedException{
		Thread.sleep(5000);
		bow.type( this.email, "Admin120520170077@gmail.com");
		bow.type(  this.password, "Test12");
		bow.clickIT( button);
	}
	public void login_negtestcase1(String email11,String password1) throws InterruptedException{
		Thread.sleep(5000);
		
		bow.type( this.email, "Admin120520170077@gmail.com");
		bow.type(  this.password, "Test12");
		bow.clickIT( button);
		String compare = driver.findElement(By.xpath("//div[@id='loginValidations']/div[2]/div/p")).getText();
		String compare2 = " One required";
		Assert.assertEquals(compare,compare2);
	}

}
