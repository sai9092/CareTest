package utlitty;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ReadExcel {

	
	static XSSFWorkbook wb;
	static XSSFSheet sheet;
	static XSSFRow row;
	static XSSFCell cell;
	

	/*public static String readExcel(int rowNumber, int cellNumber) throws IOException {
		//String str = new SimpleDateFormat("yyyyMMddHHmmss").format(new Date());

		FileInputStream fis = new FileInputStream(new File("C:\\Users\\fiuser1\\Desktop\\Dialcaretest.xlsx"));
		wb = new XSSFWorkbook(fis);

		sheet = wb.getSheet("sheet1");

		row = sheet.getRow(rowNumber);

		fis.close();

		return row.getCell(cellNumber).getStringCellValue();
		

	}*/
	// the below code is to do some experiment.
	public static String readExcel(int rowNumber, int cellNumber,String sheetname) throws IOException {
		//String str = new SimpleDateFormat("yyyyMMddHHmmss").format(new Date());

		FileInputStream fis = new FileInputStream(new File("C:\\Users\\fiuser1\\Desktop\\Dialcaretest.xlsx"));
		wb = new XSSFWorkbook(fis);

		sheet = wb.getSheet(sheetname);
		//the below loop is to get all sheets in the excell
		/*for(Sheet sheet: wb) {
            System.out.println("=> " + sheet.getSheetName());
        }*/
		
		DataFormatter df = new DataFormatter();

		row = sheet.getRow(rowNumber);
		
		fis.close();
		XSSFCell cellval = row.getCell(cellNumber);
		String formattedvalue = df.formatCellValue(cellval);
		return formattedvalue;

		//return df.formatCellValue(row.getCell(cellNumber));
		

	}
	
	
	
	
}
