package careing_ton.CareingTon;

import org.testng.TestNG;
import org.testng.annotations.Test;

/**
 * Unit test for simple App.
 */
public class AppTest 
  
{
   
}
